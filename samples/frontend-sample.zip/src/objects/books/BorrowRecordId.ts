export type BorrowRecordId = string
