export type InstantString = string
